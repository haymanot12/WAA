import React from 'react';

export const UpperComponent4 = ({ count4 }) => {
let content =
<div>
<p>
{count4}
</p>
</div>
return content ;
}