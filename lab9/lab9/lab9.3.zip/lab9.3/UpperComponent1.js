import React from 'react';

export const UpperComponent1 = ({ count1 }) => {
let content =
<div>
<p>
{count1}
</p>
</div>
return content ;
}