import React from 'react';

export const UpperComponent3 = ({ count3 }) => {
let content =
<div>
<p>
{count3}
</p>
</div>
return content ;
}