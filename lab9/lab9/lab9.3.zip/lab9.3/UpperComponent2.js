import React from 'react';

export const UpperComponent2 = ({ count2 }) => {
let content =
<div>
<p>
{count2}
</p>
</div>
return content ;
}