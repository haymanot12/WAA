import React from 'react';

export const UpperComponent1 = ({ count }) => {
let content =
<div>
<p>
{count}
</p>
</div>
return content ;
}