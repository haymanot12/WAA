import React from 'react';

export const UpperComponent2 = ({ count }) => {
let content =
<div>
<p>
{count}
</p>
</div>
return content ;
}