Lab progress:

all functionalities are done 


I hereby declare that this submission is my own original work and to the best of my 
knowledge it contains no materials previously published or written by another person. 
I am aware that submitting solutions that are not my own work will result in an NC of 
the course.
 [Haymanot Adane]